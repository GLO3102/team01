
var actorApp = angular.module('uMovie.actor', ['ngRoute']);