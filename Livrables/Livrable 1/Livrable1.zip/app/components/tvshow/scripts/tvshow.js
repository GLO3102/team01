'use strict';

var tvShowApp = angular.module('uMovie.tvshow', ['ngRoute']);
