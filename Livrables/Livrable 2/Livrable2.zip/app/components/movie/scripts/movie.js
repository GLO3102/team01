'use strict';

var movieApp = angular.module('uMovie.movie', ['ngRoute', 'watchlistDropdown', 'priceToggle']);