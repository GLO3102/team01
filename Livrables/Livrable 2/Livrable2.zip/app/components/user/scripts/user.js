/**
 * Created by Antoine on 2015-10-15.
 */
var userApp = angular.module('uMovie.user', ['ngRoute']);