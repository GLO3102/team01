/**
 * Created by Antoine on 2015-10-15.
 */
userApp.controller("user-controller", function ($scope,  $routeParams) {
    var userID =  $routeParams.userId;

});