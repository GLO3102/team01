'use strict';

var searchApp = angular.module('uMovie.search', ['ngRoute']);