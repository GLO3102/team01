'use strict';

var actorApp = angular.module('uMovie.actor', ['ngRoute']);
