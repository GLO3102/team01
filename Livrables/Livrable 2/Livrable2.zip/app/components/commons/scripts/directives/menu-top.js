/**
 * Created by Pascal on 2015-10-28.
 */
homeApp.directive('menu-top', function() {
    return {
        restrict: 'E',
        templateUrl: 'components/commons/views/menuTop.html'
    };
});